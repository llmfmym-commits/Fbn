package com.abolfazl.tabdilgarasnad;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View.OnClickListener comingSoon = v ->
                Toast.makeText(this, R.string.coming_soon, Toast.LENGTH_SHORT).show();

        // Phase 1 (this build): only the app shell + navigation exist.
        // Each feature below is wired to its own screen in later phases:
        //   Phase 2 -> Image to PDF
        //   Phase 3 -> PDF viewer/editor
        //   Phase 4 -> Word <-> PDF conversion
        //   Phase 5 -> PowerPoint viewer
        //   Phase 6 -> PowerPoint creation
        findViewById(R.id.card_image_to_pdf).setOnClickListener(comingSoon);
        findViewById(R.id.card_view_pdf).setOnClickListener(comingSoon);
        findViewById(R.id.card_word_to_pdf).setOnClickListener(comingSoon);
        findViewById(R.id.card_pdf_to_word).setOnClickListener(comingSoon);
        findViewById(R.id.card_powerpoint_view).setOnClickListener(comingSoon);
        findViewById(R.id.card_powerpoint_create).setOnClickListener(comingSoon);
    }
}
